/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;


import javax.swing.*;

public class ReservaArea extends JFrame {

    public ReservaArea() {
        setTitle("Reserva de Área de Lazer");
        setSize(400, 250);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel lblArea = new JLabel("Área:");
        lblArea.setBounds(30, 30, 100, 20);
        add(lblArea);

        String[] areas = {"Piscina", "Quadra", "Salão de Eventos"};
        JComboBox<String> comboArea = new JComboBox<>(areas);
        comboArea.setBounds(130, 30, 180, 20);
        add(comboArea);

        JLabel lblData = new JLabel("Data:");
        lblData.setBounds(30, 70, 100, 20);
        add(lblData);

        JTextField txtData = new JTextField("dd/mm/aaaa");
        txtData.setBounds(130, 70, 180, 20);
        add(txtData);

        JButton btnReservar = new JButton("Reservar");
        btnReservar.setBounds(130, 120, 100, 30);
        add(btnReservar);

        btnReservar.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Reserva registrada!");
        });
    }
}
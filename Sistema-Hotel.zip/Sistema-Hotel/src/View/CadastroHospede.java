/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import javax.swing.*;
import Model.Hospede;
import Controller.DadosApp;

public class CadastroHospede extends JFrame {
    public CadastroHospede() {
        setTitle("Cadastro de Hóspede");
        setSize(350, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        JLabel lblNome = new JLabel("Nome:");
        lblNome.setBounds(20, 30, 80, 25);
        JTextField txtNome = new JTextField();
        txtNome.setBounds(100, 30, 200, 25);

        JLabel lblCpf = new JLabel("CPF:");
        lblCpf.setBounds(20, 70, 80, 25);
        JTextField txtCpf = new JTextField();
        txtCpf.setBounds(100, 70, 200, 25);

        JLabel lblDias = new JLabel("Dias Hospedagem:");
        lblDias.setBounds(20, 110, 120, 25);
        JTextField txtDias = new JTextField();
        txtDias.setBounds(150, 110, 150, 25);

        JButton btnSalvar = new JButton("Salvar");
        btnSalvar.setBounds(100, 160, 150, 30);

        JButton btnVoltar = new JButton("Voltar");
        btnVoltar.setBounds(100, 200, 150, 30);

        add(lblNome); add(txtNome);
        add(lblCpf); add(txtCpf);
        add(lblDias); add(txtDias);
        add(btnSalvar); add(btnVoltar);

      btnSalvar.addActionListener(e -> {
    try {
        String nome = txtNome.getText();
        String cpf = txtCpf.getText();
        int dias = Integer.parseInt(txtDias.getText());

        Hospede h = new Hospede(nome, cpf, dias);
        DadosApp.listaHospedes.add(h);
        DadosApp.salvarDados(); // Salvar após adicionar
        JOptionPane.showMessageDialog(this, "Hóspede cadastrado!");

        txtNome.setText(""); txtCpf.setText(""); txtDias.setText("");
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "Erro nos dados: " + ex.getMessage());
    }
});

        btnVoltar.addActionListener(e -> {
            new TelaInicial().setVisible(true);
            dispose();
        });
    }
}

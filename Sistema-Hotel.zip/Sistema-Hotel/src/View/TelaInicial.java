/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import javax.swing.*;

public class TelaInicial extends JFrame {

    public TelaInicial() {
        setTitle("Sistema de Hotel - Menu");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JButton btnCadastro = new JButton("Cadastrar Hóspede");
        btnCadastro.setBounds(100, 30, 200, 40);
        add(btnCadastro);

        JButton btnConsulta = new JButton("Consultar Hóspedes");
        btnConsulta.setBounds(100, 80, 200, 40);
        add(btnConsulta);

        JButton btnReserva = new JButton("Reservar Área de Lazer");
        btnReserva.setBounds(100, 130, 200, 40);
        add(btnReserva);

        btnCadastro.addActionListener(e -> {
            new CadastroHospede().setVisible(true);
        });

        btnConsulta.addActionListener(e -> {
            new ConsultaHospede().setVisible(true);
        });

        btnReserva.addActionListener(e -> {
            new ReservaArea().setVisible(true);
        });
    }
}

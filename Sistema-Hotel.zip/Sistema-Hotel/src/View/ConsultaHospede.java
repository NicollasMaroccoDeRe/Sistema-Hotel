/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import javax.swing.*;
import Controller.DadosApp;
import Model.Hospede;

public class ConsultaHospede extends JFrame {
    public ConsultaHospede() {
        setTitle("Lista de Hóspedes");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        JTextArea area = new JTextArea();
        area.setBounds(20, 20, 340, 180);
        area.setEditable(false);
        add(area);

        JButton btnVoltar = new JButton("Voltar");
        btnVoltar.setBounds(140, 220, 100, 30);
        add(btnVoltar);

        StringBuilder sb = new StringBuilder();
        for (Hospede h : DadosApp.listaHospedes) {
            sb.append(h.toString()).append("\\n");
        }
        area.setText(sb.toString());

        btnVoltar.addActionListener(e -> {
            new TelaInicial().setVisible(true);
            dispose();
        });
    }
}
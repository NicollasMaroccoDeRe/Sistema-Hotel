/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.*;
import java.util.*;

public class HospedeDAO {
    public void cadastrarHospede(String nome, String cpf, int dias) {
        String sql = "INSERT INTO hospedes (nome, cpf, dias_hospedagem, despesas) VALUES (?, ?, ?, 0.0)";
        try (Connection con = Conexao.conectar(); PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, nome);
            stmt.setString(2, cpf);
            stmt.setInt(3, dias);
            stmt.executeUpdate();
            System.out.println("Hóspede cadastrado com sucesso.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<String> listarHospedes() {
        List<String> lista = new ArrayList<>();
        String sql = "SELECT nome, cpf, despesas FROM hospedes";
        try (Connection con = Conexao.conectar(); PreparedStatement stmt = con.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String linha = rs.getString("nome") + " - CPF: " + rs.getString("cpf") + " - R$ " + rs.getDouble("despesas");
                lista.add(linha);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
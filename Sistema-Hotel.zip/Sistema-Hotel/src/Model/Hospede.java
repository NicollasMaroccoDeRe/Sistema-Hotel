/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.io.Serializable;

public class Hospede implements Serializable {
    private static final long serialVersionUID = 1L;

    private String nome;
    private String cpf;
    private int diasHospedagem;
    private double despesas;

    public Hospede(String nome, String cpf, int diasHospedagem) {
        this.nome = nome;
        this.cpf = cpf;
        this.diasHospedagem = diasHospedagem;
        this.despesas = diasHospedagem * 100.0;
    }

    public String getNome() { return nome; }
    public String getCpf() { return cpf; }
    public int getDiasHospedagem() { return diasHospedagem; }
    public double getDespesas() { return despesas; }

    @Override
    public String toString() {
        return nome + " | CPF: " + cpf + " | Total: R$" + despesas;
    }
}

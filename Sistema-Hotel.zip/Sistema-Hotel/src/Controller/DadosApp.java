/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;


import java.io.*;
import java.util.ArrayList;
import java.util.List;
import Model.Hospede;

public class DadosApp {
    public static List<Hospede> listaHospedes = new ArrayList<>();
    private static final String NOME_ARQUIVO = "hospedes.dat";

    // Carrega os dados do arquivo ao iniciar
    static {
        carregarDados();
    }

    public static void salvarDados() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(NOME_ARQUIVO))) {
            out.writeObject(listaHospedes);
        } catch (IOException e) {
            System.out.println("Erro ao salvar os dados: " + e.getMessage());
        }
    }

    public static void carregarDados() {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(NOME_ARQUIVO))) {
            listaHospedes = (List<Hospede>) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            // Caso o arquivo ainda não exista, mantemos a lista vazia
            listaHospedes = new ArrayList<>();
        }
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistema.hotel;

import View.TelaInicial;

public class SistemaHotel {
    public static void main(String[] args) {
        new TelaInicial().setVisible(true);
    }
}
